export type MediaSlot =
  | "home_hero_primary"
  | "home_hero_secondary"
  | "home_strip_stats"
  | "home_student_story"
  | "home_employer_collage"
  | "program_cna_hero"
  | "program_barber_hero"
  | "program_hvac_hero"
  | "program_cdl_hero"
  | "program_tax_hero";

export interface MediaConfigItem {
  slot: MediaSlot;
  imageSrc: string;
  alt: string;
}

/**
 * IMPORTANT:
 *  - Update imageSrc to match REAL files in /public (or /public/media/...).
 *  - These are the ONLY places you need to change to swap images across the site.
 */
export const mediaConfig: MediaConfigItem[] = [
  {
    slot: "home_hero_primary",
    imageSrc: "/media/home/hero-primary.jpg",
    alt: "Learners in a training lab celebrating success.",
  },
  {
    slot: "home_hero_secondary",
    imageSrc: "/media/home/hero-secondary.jpg",
    alt: "Instructor supporting a learner on the job.",
  },
  {
    slot: "home_strip_stats",
    imageSrc: "/media/home/stats-strip.jpg",
    alt: "Collage representing Elevate outcomes and impact.",
  },
  {
    slot: "home_student_story",
    imageSrc: "/media/home/student-story.jpg",
    alt: "Graduate in scrubs smiling after landing a healthcare job.",
  },
  {
    slot: "home_employer_collage",
    imageSrc: "/media/home/employer-collage.jpg",
    alt: "Employers shaking hands with Elevate learners.",
  },
  {
    slot: "program_cna_hero",
    imageSrc: "/media/programs/cna-hero.jpg",
    alt: "CNA learner supporting an older adult in a care facility.",
  },
  {
    slot: "program_barber_hero",
    imageSrc: "/media/programs/barber-hero.jpg",
    alt: "Barber apprentice cutting hair in a modern shop.",
  },
  {
    slot: "program_hvac_hero",
    imageSrc: "/media/programs/hvac-hero.jpg",
    alt: "HVAC tech working on rooftop unit.",
  },
  {
    slot: "program_cdl_hero",
    imageSrc: "/media/programs/cdl-hero.jpg",
    alt: "Student standing in front of a commercial truck.",
  },
  {
    slot: "program_tax_hero",
    imageSrc: "/media/programs/tax-hero.jpg",
    alt: "Tax preparer helping a family with their return.",
  },
];

export function getMediaBySlot(slot: MediaSlot) {
  return mediaConfig.find((m) => m.slot === slot);
}
