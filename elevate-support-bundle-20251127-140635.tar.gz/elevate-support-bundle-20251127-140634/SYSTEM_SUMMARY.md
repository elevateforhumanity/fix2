# Elevate for Humanity - Support Bundle

**Generated:** $(date)
**Version:** 2.0
**Build Status:** Production Ready

## What's Included

### Documentation (`/docs`)
- Current active documentation
- Deployment guides
- Development setup guides
- Route map and environment config

### Configuration (`/config`)
- package.json - Dependencies and scripts
- next.config.mjs - Next.js configuration
- tsconfig.json - TypeScript configuration
- tailwind.config.cjs - Styling configuration
- supabaseServer.ts - Database client

### Data Libraries (`/data`)
- All lms-data configuration files
- Program catalogs
- Funding profiles
- AI instructor personas
- Media slot configurations
- Site health checklist

### Components (`/components`)
- HeroBanner - Reusable hero section
- ImageSection - Content sections with images
- CoursePlayer - Course playback interface
- EnrollmentPaymentWidget - Stripe integration
- RatingStars - Review system component

### Key Pages (`/pages`)
- home-v2 - New homepage layout
- admin/site-health - Launch checklist dashboard
- admin/analytics - Program analytics
- admin/ai-console - AI management

## System Overview

### Total Pages: 461+
### Total Systems: 15+
### Build Status: ✅ Passing

## Critical Environment Variables

```bash
NEXT_PUBLIC_SITE_URL=https://www.elevateforhumanity.org
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_key
STRIPE_SECRET_KEY=your_stripe_secret
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_stripe_public
OPENAI_API_KEY=your_openai_key
```

## Quick Start

1. Install dependencies:
   ```bash
   npm install
   ```

2. Set environment variables in `.env.local`

3. Run development server:
   ```bash
   npm run dev
   ```

4. Build for production:
   ```bash
   npm run build
   ```

## Key Features

- ✅ 11 Training Programs (CNA, HVAC, CDL, Barber, etc.)
- ✅ Stripe Payment Processing
- ✅ OpenAI AI Tutoring (4 personas)
- ✅ JRI SCORM Module Support
- ✅ Employer Partnership Tracking
- ✅ Analytics & Reporting
- ✅ Site Health Monitoring
- ✅ Funding Stream Management
- ✅ Course Player with Supabase
- ✅ Media Slot System

## Support

For questions or issues:
- Check `/docs/README.md` for documentation index
- Review `/docs/ROUTE_MAP.md` for routing
- See `/docs/ENV_CONFIG.md` for environment setup
- Visit `/admin/site-health` for system status

## Next Steps

1. Upload JRI SCORM modules to `/public/scorm/jri/`
2. Add real images to `/public/media/`
3. Configure Stripe products in `lms-data/billingConfig.ts`
4. Test enrollment flow end-to-end
5. Deploy to production

---

**Built with ❤️ for Elevate for Humanity**
