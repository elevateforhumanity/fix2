# Changelog

## 1.0.0

- Initial production baseline (tooling, tests, env validation, CI)
