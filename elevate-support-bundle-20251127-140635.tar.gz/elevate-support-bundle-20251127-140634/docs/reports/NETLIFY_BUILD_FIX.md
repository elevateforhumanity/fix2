fatal: path 'NETLIFY_BUILD_FIX.md' exists on disk, but not in 'fix/zero-errors-production'
