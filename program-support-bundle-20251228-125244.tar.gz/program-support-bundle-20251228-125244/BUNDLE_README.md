# Program Support Bundle

## Contents

1. **app/data/programs.ts** - Current program data (13 programs)
2. **lib/programs-data-complete.ts** - Complete program library (31 programs)
3. **lib/payment-config.ts** - Payment configuration and pricing
4. **syllabi/** - All 18 ETPL program syllabi
5. **PROGRAM_FUNDING_BREAKDOWN.md** - Funding analysis
6. **ACTUAL_ETPL_PROGRAMS.md** - Complete ETPL program list

## Current Status

### Programs in app/data/programs.ts (11 ETPL + 2 unverified):
1. barber-apprenticeship ✅
2. beauty-career-educator ✅
3. building-maintenance-tech ✅
4. business-startup-marketing ✅
5. cdl-training ✅
6. certified-peer-recovery-coach ✅
7. cna-certification (no syllabus - verify)
8. direct-support-professional (no syllabus - verify)
9. emergency-health-safety-tech ✅
10. hvac-technician ✅
11. phlebotomy-technician ✅
12. professional-esthetician ✅
13. tax-prep-financial-services ✅

### Missing ETPL Programs (6):
1. culinary-arts
2. electrical
3. it-support-specialist
4. medical-administrative-assistant
5. certified-peer-support-professional
6. welding

### Self-Pay Courses (11):
1. cpr-certification
2. customer-service-retail-nrf
3. cybersecurity-fundamentals
4. hospitality-culinary
5. microsoft-office-mos
6. osha-10-certification
7. osha-30-careersafe
8. patient-care-technician
9. pharmacy-technician
10. rise-up-certificate
11. it-support (if not ETPL)

## EMS/EMT Programs

**Emergency Health & Safety Tech** includes:
- Emergency Medical Responder (EMR) certification
- OSHA 10
- CPR
- 4-week DOL Registered Apprenticeship

No separate EMS/EMT program found in syllabi.

## Next Steps

1. Add 6 missing ETPL programs to app/data/programs.ts
2. Verify CNA and DSP status
3. Add payment links to all programs
4. Update /programs page to show all ETPL programs
